The optimized version of the code is asm_mont1, since asm_mont still has a bug.

The assembly function are defined in asm_mont.S
