#ifndef ASM_MONT_ADD_H_
#define ASM_MONT_ADD_H_

#include <stdint.h>
void asm_mont_add(uint32_t* t, uint32_t index, uint32_t c);
#endif
