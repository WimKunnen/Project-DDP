#ifndef ASM_CONDITIONAL_SUB_H_
#define ASM_CONDITIONAL_SUB_H_

#include <stdint.h>
void asm_cond_sub(uint32_t* u, uint32_t* n, uint32_t size);
#endif

